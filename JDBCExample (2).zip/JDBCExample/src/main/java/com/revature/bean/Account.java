/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.revature.bean;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author damaniobie
 */
public class Account {
    
	public static int numAccounts = 0;
    private int accountid;
    private String accountNumber;
    private double balance;
    private boolean accountTypeJoint; // is joint account or not
    private boolean approved;
    private String userID;
    private List <User> userList = new ArrayList<User>();
    
    public Account(){
        super();
        this.generateAccountIDNumber();
        this.userList = new ArrayList<User>();
    }
    
    public Account(int accountid, boolean accountTypeJoint,double balance,User u){
        //this.accountNumber = accountNumber;
        this.accountid = accountid;
        this.accountTypeJoint = accountTypeJoint;
        this.balance = balance;
        this.userList.add(u);
        this.approved = true;
        this.generateAccountIDNumber();
        numAccounts++;
    }
    
    
    public int getId(){return this.accountid;}
    
    public void setId(int accountid){this.accountid = accountid;}
    
    public String getAccountNumber(){return this.accountNumber;}
    
    public void setAccountNumber(String accountNumber){this.accountNumber = accountNumber;}
    
    public double getBalance(){return this.balance;}
    
    public void setBalance(double balance){this.balance = balance;}
    
    public boolean getAccountTypeJoint(){return this.accountTypeJoint;}
    
    public void setAccountTypeJoint(boolean accountTypeJoint){this.accountTypeJoint = accountTypeJoint;}
    
    public boolean getApproved(){return this.approved;}
    
    public void setApproved(boolean approved){this.approved = approved;}
    
    public void deposit(double amount) {
    	this.balance += amount;
    }
    
    public void withdraw(double amount) {
    	this.balance -= amount;
    }
    
    public void transferTo(double amount,Account acc) {
    	this.balance -= amount;
    	acc.balance += amount;
    }
    
    public void setUserID(String userid) {
    	this.userID = userid;
    }
    
    public String getUserID() {
    	return this.userID;
    }
    
    public void generateAccountIDNumber(){
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvxyz"; 
        int n = 7;
        StringBuilder sb = new StringBuilder(n); 
        for (int i = 0; i < n; i++) { 
            int index = (int)(AlphaNumericString.length() * Math.random()); 
            sb.append(AlphaNumericString.charAt(index)); 
        } 
        this.accountNumber = "AC-"+sb.toString(); 
    }
    
    public String toString(){
        return "\nAccount Id: "+this.accountid+"\nAccount Number: "+this.accountNumber+""
        		+ "\nOpen: "+this.approved+"\nJoint: "+this.accountTypeJoint+"\nBalance: "+this.balance+"\n";
    }
    
    
    
    
}

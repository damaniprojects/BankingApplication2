package com.revature;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.revature.bean.Account;
import com.revature.bean.User;
import com.revature.dao.AccountDao;
import com.revature.dao.AccountDaoImpl;
import com.revature.dao.UserDao;
import com.revature.dao.UserDaoImpl;
import com.revature.util.ConnectionFactory;




public class CustomerView {

private static UserDao userDao = new UserDaoImpl(ConnectionFactory.getConnection());
private static AccountDao accountDao = new AccountDaoImpl(ConnectionFactory.getConnection());


	public CustomerView(String uname, String password) throws NumberFormatException, IOException {
		boolean userLoop = true;
		boolean logOutLoop = true;
	InputStreamReader r=new InputStreamReader(System.in);    
    BufferedReader br=new BufferedReader(r); 
    int l_r;
    
	System.out.println("1. register\n2. login\n3. Change password ");
	l_r = Integer.parseInt(br.readLine());
	if(l_r == 1) {
		 int rand = (int) (Math.random()*1000+1);
		System.out.println("Enter a ssn");
		String ssn = br.readLine();
		System.out.println("Enter a phone number");
		String phone = br.readLine();
		userDao.createUser(new User(rand,uname,password,ssn,phone,1));
	}else if(l_r == 2) {
		User u = userDao.getUserByUsername(uname);
		if(u != null) {
			if(u.getUsername().equals(uname) && u.getPassword().equals(password) && u.getType() == 1) {
			System.out.println("\nLog in successful\n");
		}else {
			System.out.println("\nLog in failed\n");
			logOutLoop = false;
			userLoop = false;
		}
		}else {
			System.out.println("That username is not in our database");
			logOutLoop = false;
			userLoop = false;
		}
	}else if(l_r == 3) {
		System.out.println("Select your new password");
		String newPassword = br.readLine();
		User u = userDao.getUserByUsername(uname);
		u.setPassword(newPassword);
		userDao.updateUser(u);
	}
	while(userLoop) {
customerMenu();
int option = Integer.parseInt(br.readLine());
if(option == 1) {
	 int rand = (int) (Math.random()*100000+1);
	if(userDao.getUserByUsername(uname).getApprovedStatus()) {
		User u = userDao.getUserByUsername(uname);
		accountDao.createAccount(new Account(rand,false,0.0,u));
		Account a = accountDao.getAccountById(rand);
		System.out.println("Account Successfully added. Account number is: "+a.getAccountNumber());
		u.setAccountNumber(a.getAccountNumber());
		userDao.updateUser(u);
	}else {
		System.out.println("You must first be approved by an employee");
	}
}else if(option == 2) {
	 int rand = (int) (Math.random()*100000+1);
	if(userDao.getUserByUsername(uname).getApprovedStatus()) {
		User u = userDao.getUserByUsername(uname);
		accountDao.createAccount(new Account(rand,true,0.0,userDao.getUserByUsername(uname)));
		Account a = accountDao.getAccountById(rand);
		System.out.println("Account Successfully added. Account number is: "+a.getAccountNumber());
		u.setAccountNumber(a.getAccountNumber());
		userDao.updateUser(u);
	}else {
		System.out.println("You must first be approved by an employee");
	}
}else if(option == 3) {
	if(userDao.getUserByUsername(uname).getAccountNumber() != null) {
		System.out.println("Your accounts: "+ userDao.getUserByUsername(uname).getAccountNumber() +"\n\nEnter the account number of the account you'd like to deposit");
		String id = br.readLine();
		Account a = accountDao.getAccountByAccountNumber(id);
		System.out.println("How much would you like to deposit?");
		double amount = Double.parseDouble(br.readLine());
		if(amount > 0) {
		accountDao.updateAccountDeposit(a, amount);
		System.out.println(amount + " has been deposited into Account "+a.getAccountNumber());
		}else {
			System.out.println("Invalid amount");
		}
	}else {
		System.out.println("You must first apply for an account");
	}
}else if(option == 4) {
	if(userDao.getUserByUsername(uname).getAccountNumber() != null) {
		System.out.println("Your accounts: "+ userDao.getUserByUsername(uname).getAccountNumber() +"\n\nEnter the account number of the account you'd like to deposit");
		String id = br.readLine();
		Account a = accountDao.getAccountByAccountNumber(id);
		System.out.println("How much would you like to withdraw? Your balance is: "+a.getBalance());
		double amount = Double.parseDouble(br.readLine());
		if(amount > 0 && amount < a.getBalance()) {
		accountDao.updateAccountWithdraw(a, amount);
		System.out.println(amount + " has been withdrawn from Account "+a.getAccountNumber());
		}else {
			System.out.println("Invalid amount");
		}
	}else {
		System.out.println("You must first apply for an account");
	}
}else if(option == 5) {
	if(userDao.getUserByUsername(uname).getAccountNumber() != null) {
		System.out.println("Your accounts: "+ userDao.getUserByUsername(uname).getAccountNumber() +"\nEnter the account number of the account you'd like to transfer from");
		String id = br.readLine();
		System.out.println("List of accounts: ");
		for(Account a : accountDao.getAllAccounts()) {
			if(!a.getAccountNumber().equals(id)) {
			accountDao.seeAccountInfo(a);
			System.out.println();
			}
		}
		Account a = new Account();
		Account a2 = new Account();
		System.out.println("Enter the account number of the account you'd like to transfer to");
		String id2 = br.readLine();
		if(!id.equals(id2)) {
		 a = accountDao.getAccountByAccountNumber(id);
		 a2 = accountDao.getAccountByAccountNumber(id2);
		}else {
			System.out.println("You cannot transfer to the same account. Nice try though..\n\n");
			break;
			
		}
		System.out.println("How much would you like to transfer? Your balance is: "+a.getBalance());
		double amount = Double.parseDouble(br.readLine());
		if(amount > 0 && amount < a.getBalance()) {
		accountDao.updateTransfer(a, a2,amount);
		System.out.println(amount + " has been transfered from Account "+a.getAccountNumber() + " and into Account "+a2.getAccountNumber());
		}else {
			System.out.println("Invalid transfer");
		}
	}else {
		System.out.println("You must first apply for an account");
	}
}else if(option == 6) {
	if(userDao.getUserByUsername(uname).getAccountNumber() != null) {
		System.out.println("Enter the account number of the account you'd like to check");
		String id = br.readLine();
		Account a = accountDao.getAccountByAccountNumber(id);
		accountDao.seeAccountInfo(a);
	}
}else if(option == 7) {
	userLoop = false;
	logOutLoop = false;
	break;
	
}
	}
	}
	static void customerMenu(){
	    System.out.println("What would you like to do?"
	            + "\n1. Apply for an account\n2. Apply for a joint account"
	            + "\n3. Deposit funds\n4. Withdraw\n5. Transfer funds\n6. Check account info \n7. Logout");
	}

}


/*
System.out.println("1. register\n2. login\n3. Change password ");
l_r = Integer.parseInt(br.readLine());
if(l_r == 1) {
	 int rand = (int) (Math.random()*1000+1);
	System.out.println("Enter a ssn");
	String ssn = br.readLine();
	System.out.println("Enter a phone number");
	String phone = br.readLine();
	userDao.createUser(new User(rand,uname,password,ssn,phone,1));
}else if(l_r == 2) {
	User u = userDao.getUserByUsername(uname);
	if(u != null) {
		if(u.getUsername().equals(uname) && u.getPassword().equals(password) && u.getType() == 1) {
		System.out.println("\nLog in successful\n");
	}else {
		System.out.println("\nLog in failed\n");
		logOutLoop = false;
		userLoop = false;
	}
	}else {
		System.out.println("That username is not in our database");
		logOutLoop = false;
		userLoop = false;
	}
}else if(l_r == 3) {
	System.out.println("Select your new password");
	String newPassword = br.readLine();
	User u = userDao.getUserByUsername(uname);
	u.setPassword(newPassword);
	userDao.updateUser(u);
}
while(userLoop) {
customerMenu();
int option = Integer.parseInt(br.readLine());
if(option == 1) {
 int rand = (int) (Math.random()*100000+1);
if(userDao.getUserByUsername(uname).getApprovedStatus()) {
	User u = userDao.getUserByUsername(uname);
	accountDao.createAccount(new Account(rand,false,0.0,u));
	Account a = accountDao.getAccountById(rand);
	System.out.println("Account Successfully added. Account number is: "+a.getAccountNumber());
	u.setAccountNumber(a.getAccountNumber());
	userDao.updateUser(u);
}else {
	System.out.println("You must first be approved by an employee");
}
}else if(option == 2) {
 int rand = (int) (Math.random()*100000+1);
if(userDao.getUserByUsername(uname).getApprovedStatus()) {
	User u = userDao.getUserByUsername(uname);
	accountDao.createAccount(new Account(rand,true,0.0,userDao.getUserByUsername(uname)));
	Account a = accountDao.getAccountById(rand);
	System.out.println("Account Successfully added. Account number is: "+a.getAccountNumber());
	u.setAccountNumber(a.getAccountNumber());
	userDao.updateUser(u);
}else {
	System.out.println("You must first be approved by an employee");
}
}else if(option == 3) {
if(userDao.getUserByUsername(uname).getAccountNumber() != null) {
	System.out.println("Your accounts: "+ userDao.getUserByUsername(uname).getAccountNumber() +"\n\nEnter the account number of the account you'd like to deposit");
	String id = br.readLine();
	Account a = accountDao.getAccountByAccountNumber(id);
	System.out.println("How much would you like to deposit?");
	double amount = Double.parseDouble(br.readLine());
	if(amount > 0) {
	accountDao.updateAccountDeposit(a, amount);
	System.out.println(amount + " has been deposited into Account "+a.getAccountNumber());
	}else {
		System.out.println("Invalid amount");
	}
}else {
	System.out.println("You must first apply for an account");
}
}else if(option == 4) {
if(userDao.getUserByUsername(uname).getAccountNumber() != null) {
	System.out.println("Your accounts: "+ userDao.getUserByUsername(uname).getAccountNumber() +"\n\nEnter the account number of the account you'd like to deposit");
	String id = br.readLine();
	Account a = accountDao.getAccountByAccountNumber(id);
	System.out.println("How much would you like to withdraw? Your balance is: "+a.getBalance());
	double amount = Double.parseDouble(br.readLine());
	if(amount > 0 && amount < a.getBalance()) {
	accountDao.updateAccountWithdraw(a, amount);
	System.out.println(amount + " has been withdrawn from Account "+a.getAccountNumber());
	}else {
		System.out.println("Invalid amount");
	}
}else {
	System.out.println("You must first apply for an account");
}
}else if(option == 5) {
if(userDao.getUserByUsername(uname).getAccountNumber() != null) {
	System.out.println("Your accounts: "+ userDao.getUserByUsername(uname).getAccountNumber() +"\nEnter the account number of the account you'd like to transfer from");
	String id = br.readLine();
	System.out.println("List of accounts: ");
	for(Account a : accountDao.getAllAccounts()) {
		if(!a.getAccountNumber().equals(id)) {
		accountDao.seeAccountInfo(a);
		System.out.println();
		}
	}
	Account a = new Account();
	Account a2 = new Account();
	System.out.println("Enter the account number of the account you'd like to transfer to");
	String id2 = br.readLine();
	if(!id.equals(id2)) {
	 a = accountDao.getAccountByAccountNumber(id);
	 a2 = accountDao.getAccountByAccountNumber(id2);
	}else {
		System.out.println("You cannot transfer to the same account. Nice try though..\n\n");
		break;
		
	}
	System.out.println("How much would you like to transfer? Your balance is: "+a.getBalance());
	double amount = Double.parseDouble(br.readLine());
	if(amount > 0 && amount < a.getBalance()) {
	accountDao.updateTransfer(a, a2,amount);
	System.out.println(amount + " has been transfered from Account "+a.getAccountNumber() + " and into Account "+a2.getAccountNumber());
	}else {
		System.out.println("Invalid transfer");
	}
}else {
	System.out.println("You must first apply for an account");
}
}else if(option == 6) {
if(userDao.getUserByUsername(uname).getAccountNumber() != null) {
	System.out.println("Enter the account number of the account you'd like to check");
	String id = br.readLine();
	Account a = accountDao.getAccountByAccountNumber(id);
	accountDao.seeAccountInfo(a);
}
}else if(option == 7) {
userLoop = false;
logOutLoop = false;
}
}*/

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.revature.dao;

import com.revature.bean.Account;
import com.revature.bean.User;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author damaniobie
 */
public class AccountDaoImpl implements AccountDao{
	
/*	InputStreamReader r=new InputStreamReader(System.in);    
    BufferedReader br=new BufferedReader(r);*/
    private Connection conn;
    
    
     public void createAccount(Account a){
         try {
            PreparedStatement pstmt = conn.prepareStatement("Insert into account_table (account_id,account_number,balance,is_joint,approved, user_id) values (?,?,?,?,?,?)");
            pstmt.setInt(1,a.getId());
            pstmt.setString(2,a.getAccountNumber());
            pstmt.setDouble(3,a.getBalance());
            pstmt.setBoolean(4,a.getAccountTypeJoint());
            pstmt.setBoolean(5,a.getApproved());
            pstmt.setString(6, a.getUserID());
            pstmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
     }
	
	public void updateAccount(Account a) throws NumberFormatException, IOException{
		 /*	double amount;
            System.out.println("What would you like to do?\n1. Deposit\2. Withdraw\n3. Transfer");
            int x = Integer.parseInt(br.readLine());
            switch(x) {
            case 1:System.out.println("How much would you like to deposit?");
            amount = Double.parseDouble(br.readLine());
            break;
            case 2:System.out.println("How much would you like to withdraw?");
            amount = Double.parseDouble(br.readLine());
            break;
            case 3:System.out.println("How much would you like to transfer?");
            amount = Double.parseDouble(br.readLine());
            break;
            default:System.out.println("Invalid value");
            break;
            }*/
            
        }
	
       
	public void deleteAccount(Account a){
            try{
                    PreparedStatement pstmt = conn.prepareStatement("delete from account_table where account_number = ?");
                    pstmt.setString(1, a.getAccountNumber());
                    pstmt.executeUpdate();
                }catch(SQLException e){
                    e.printStackTrace();
                }
        }
	
        
	public Account getAccountById(Integer id){
		Account a = null;
		try {
                    PreparedStatement pstmt = conn.prepareStatement("select * from account_table where account_id = ?");
                        pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				a = new Account();
				a.setId(rs.getInt(1));
				a.setAccountNumber(rs.getString("account_number"));
				a.setBalance(rs.getDouble("balance"));
                a.setAccountTypeJoint(rs.getBoolean("is_joint"));
                a.setApproved(rs.getBoolean("approved"));
                a.setUserID(rs.getString("user_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return a;
        }
	
        
	public Account getAccountByAccountNumber(String accountNumber){
            Account acc = null;
		try {
                    PreparedStatement pstmt = conn.prepareStatement("select * from account_table where account_number = ?");
                        pstmt.setString(1, accountNumber);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				acc = new Account();
				acc.setId(rs.getInt(1));
				acc.setAccountNumber(rs.getString("account_number"));
				acc.setBalance(rs.getDouble("balance"));
                acc.setAccountTypeJoint(rs.getBoolean("is_joint"));
                acc.setApproved(rs.getBoolean("approved"));
                acc.setUserID(rs.getString("user_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return acc;
        }
	
       
	public List <Account> getAllAccounts(){
		Account acc = null;
            List <Account> accountList = new ArrayList<Account>();
            try{
                    PreparedStatement pstmt = conn.prepareStatement("select * from account_table");
                    ResultSet rs = pstmt.executeQuery();
                    while(rs.next()){
                    	acc = new Account();
                    	acc.setId(rs.getInt(1));
        				acc.setAccountNumber(rs.getString("account_number"));
        				acc.setBalance(rs.getDouble("balance"));
                        acc.setAccountTypeJoint(rs.getBoolean("is_joint"));
                        acc.setApproved(rs.getBoolean("approved"));
                        acc.setUserID(rs.getString("user_id"));
                        accountList.add(acc);
                    }
                }catch(SQLException e){
                    e.printStackTrace();
                }
            return accountList;
        }

        
        public AccountDaoImpl() {
		super();
	}
        
        
	public AccountDaoImpl(Connection conn) {
		super();
		this.conn = conn;
	}

	public void updateAccountDeposit(Account a, double amount) {
		a.deposit(amount);
		try {
			PreparedStatement pstmt = conn.prepareStatement("update account_table set balance = ? where account_number = ?");
			pstmt.setDouble(1, a.getBalance());
			pstmt.setString(2, a.getAccountNumber());
			pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}

	public void updateAccountWithdraw(Account a, double amount) {
		a.withdraw(amount);
		try {
			PreparedStatement pstmt = conn.prepareStatement("update account_table set balance = ? where account_number = ?");
			pstmt.setDouble(1, a.getBalance());
			pstmt.setString(2, a.getAccountNumber());
			pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void updateTransfer(Account a, Account b, double amount) {
		a.transferTo(amount, b);
		try {
			PreparedStatement pstmt = conn.prepareStatement("update account_table set balance = ? where account_number = ?");
			pstmt.setDouble(1, a.getBalance());
			pstmt.setString(2, a.getAccountNumber());
			PreparedStatement pstmt2 = conn.prepareStatement("update account_table set balance = ? where account_number = ?");
			pstmt2.setDouble(1, b.getBalance());
			pstmt2.setString(2, b.getAccountNumber());
			pstmt.executeUpdate();
			pstmt2.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void seeAccountInfo(Account acc) {
		
		try {
			PreparedStatement pstmt = conn.prepareStatement("select * from account_table where account_number = ?");
			pstmt.setString(1, acc.getAccountNumber());
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
            	acc.setId(rs.getInt(1));
				acc.setAccountNumber(rs.getString("account_number"));
				acc.setBalance(rs.getDouble("balance"));
                acc.setAccountTypeJoint(rs.getBoolean("is_joint"));
                acc.setApproved(rs.getBoolean("approved"));
                acc.setUserID(rs.getString("user_id"));
            }
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		System.out.println(acc.toString());
	}

	public void updateOpenAccount(Account a) {
		a.setApproved(true);
		try {
			PreparedStatement pstmt = conn.prepareStatement("update account_table set approved = ? where account_id = ?");
			pstmt.setBoolean(1, true);
			pstmt.setInt(2, a.getId());
			pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void updateCloseAccount(Account a) {
		a.setApproved(false);
		try {
			PreparedStatement pstmt = conn.prepareStatement("update account_table set approved = ? where account_id = ?");
			pstmt.setBoolean(1, false);
			pstmt.setInt(2, a.getId());
			pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}

	public void updateSetJoint(Account a) {
		// TODO Auto-generated method stub
		
	}
    
}

package com.revature;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.revature.bean.Account;
import com.revature.bean.User;
import com.revature.dao.AccountDao;
import com.revature.dao.AccountDaoImpl;
import com.revature.dao.UserDao;
import com.revature.dao.UserDaoImpl;
import com.revature.util.ConnectionFactory;

public class AdminView {
	

private static UserDao userDao = new UserDaoImpl(ConnectionFactory.getConnection());
private static AccountDao accountDao = new AccountDaoImpl(ConnectionFactory.getConnection());
	
	public AdminView(String uname,String password) throws NumberFormatException, IOException {
		boolean userLoop = true;
		boolean logOutLoop = true;
	InputStreamReader r=new InputStreamReader(System.in);    
	BufferedReader br=new BufferedReader(r); 
	int l_r;
		System.out.println("1. register\n2. login\n3. Edit info");
    	l_r = Integer.parseInt(br.readLine());
    	if(l_r == 1) {
    		 int rand = (int) (Math.random()*100000+1);
    		System.out.println("Enter a ssn");
    		String ssn = br.readLine();
    		System.out.println("Enter a phone number");
    		String phone = br.readLine();
    		userDao.createUser(new User(rand,uname,password,ssn,phone,3));
    	}else if(l_r == 2) {
    		User u = userDao.getUserByUsername(uname);
    		if(u != null) {
    			if(u.getUsername().equals(uname) && u.getPassword().equals(password) && u.getType() == 1) {
    			System.out.println("\nLog in successful\n");
    		}else {
    			System.out.println("\nLog in failed\n");
    			logOutLoop = false;
    			userLoop = false;
    		}
    		}else {
    			System.out.println("That username is not in our database");
    			logOutLoop = false;
    			userLoop = false;
    		}
    	}else if(l_r == 3) {
    		System.out.println("Select your new password");
    		String newPassword = br.readLine();
    		User u = userDao.getUserByUsername(uname);
    		u.setPassword(newPassword);
    		userDao.updateUser(u);
    	}
    	while(userLoop) {
    	adminMenu();
    	int option = Integer.parseInt(br.readLine());
    	
    	if(option == 1) {
    		System.out.println("Enter the account number of the account you'd like to deposit");
    		String id = br.readLine();
    		Account a = accountDao.getAccountByAccountNumber(id);
    		if(a != null) {
    		System.out.println("How much would you like to deposit?");
    		double amount = Double.parseDouble(br.readLine());
    		if(amount > 0) {
    		accountDao.updateAccountDeposit(a, amount);
    		System.out.println(amount + " has been deposited into Account "+a.getAccountNumber());
    		}else {
    			System.out.println("Invalid amount");
    		}
    		}else {
    			System.out.println("That account number is not in our database");
    		}
    	}else if(option == 2) {
    		System.out.println("Enter the account number of the account you'd like to withdraw");
    		String id = br.readLine();
    		Account a = accountDao.getAccountByAccountNumber(id);
    		if(a != null) {
    		System.out.println("How much would you like to withdraw?");
    		double amount = Double.parseDouble(br.readLine());
    		if(amount > 0 && amount < a.getBalance()) {
    		accountDao.updateAccountWithdraw(a, amount);
    		System.out.println(amount + " has been withdrawn from Account "+a.getAccountNumber());
    		}else {
    			System.out.println("Invalid amount");
    		}
    		}else {
    			System.out.println("That account number is not in our database");
    		}
    	}else if(option == 3) {
    		System.out.println("Enter the account number of the account you'd like to transfer from");
    		String id = br.readLine();
    		System.out.println("Enter the account number of the account you'd like to transfer to");
    		String id2 = br.readLine();
    		Account a = new Account();
    		Account a2 = new Account();
    		if(!id.equals(id2)) {
    		 a = accountDao.getAccountByAccountNumber(id);
    		 a2 = accountDao.getAccountByAccountNumber(id2);
    		}else {
    			System.out.println("You cannot transfer to the same account");
    			break;
    		}
    		if(a != null && a2 != null) {
    		System.out.println("How much would you like to transfer?");
    		double amount = Double.parseDouble(br.readLine());
    		if(amount > 0 && amount < a.getBalance()) {
    		accountDao.updateTransfer(a, a2,amount);
    		System.out.println(amount + " has been transfered from Account "+a.getAccountNumber() + " and into Account "+a2.getAccountNumber());
    		}else {
    			System.out.println("Invalid amount");
    		}
    		}else {
    			System.out.println("Invalid account numbers entered");
    		}
    	}else if(option==4) {
    		System.out.println("Enter the account number you'd like to close");
    		String id = br.readLine();
    		Account a = accountDao.getAccountByAccountNumber(id);
    		if(a != null) {
    			accountDao.updateCloseAccount(a);
    		}else {
    			System.out.println("That account doesn't exist");
    		}
    	}else if(option == 5) {
    		System.out.println("Enter the account number you'd like to open");
    		String id = br.readLine();
    		Account a = accountDao.getAccountByAccountNumber(id);
    		if(a != null) {
    			accountDao.updateOpenAccount(a);
    		}else {
    			System.out.println("That account doesn't exist in our database");
    		}
    	}else if(option == 6) {
    		logOutLoop = false;
    		userLoop = false;
    	}
    	
    	}
	}
	
	static void adminMenu(){
		System.out.println("What would you like to do?" + 
	    		"\n1. Deposit\n2. Withdraw \n3. Transfer" + 
	    		"\n4. Close Account\n5. Open Account \n6. Log out\n");
	}

}


/*
System.out.println("1. register\n2. login\n3. Edit info");
l_r = Integer.parseInt(br.readLine());
if(l_r == 1) {
	 int rand = (int) (Math.random()*100000+1);
	System.out.println("Enter a ssn");
	String ssn = br.readLine();
	System.out.println("Enter a phone number");
	String phone = br.readLine();
	userDao.createUser(new User(rand,uname,password,ssn,phone,3));
}else if(l_r == 2) {
	User u = userDao.getUserByUsername(uname);
	if(u != null) {
		if(u.getUsername().equals(uname) && u.getPassword().equals(password) && u.getType() == 1) {
		System.out.println("\nLog in successful\n");
	}else {
		System.out.println("\nLog in failed\n");
		logOutLoop = false;
		userLoop = false;
	}
	}else {
		System.out.println("That username is not in our database");
		logOutLoop = false;
		userLoop = false;
	}
}else if(l_r == 3) {
	System.out.println("Select your new password");
	String newPassword = br.readLine();
	User u = userDao.getUserByUsername(uname);
	u.setPassword(newPassword);
	userDao.updateUser(u);
}
while(userLoop) {
//adminMenu();
int option = Integer.parseInt(br.readLine());

if(option == 1) {
	System.out.println("Enter the account number of the account you'd like to deposit");
	String id = br.readLine();
	Account a = accountDao.getAccountByAccountNumber(id);
	if(a != null) {
	System.out.println("How much would you like to deposit?");
	double amount = Double.parseDouble(br.readLine());
	if(amount > 0) {
	accountDao.updateAccountDeposit(a, amount);
	System.out.println(amount + " has been deposited into Account "+a.getAccountNumber());
	}else {
		System.out.println("Invalid amount");
	}
	}else {
		System.out.println("That account number is not in our database");
	}
}else if(option == 2) {
	System.out.println("Enter the account number of the account you'd like to withdraw");
	String id = br.readLine();
	Account a = accountDao.getAccountByAccountNumber(id);
	if(a != null) {
	System.out.println("How much would you like to withdraw?");
	double amount = Double.parseDouble(br.readLine());
	if(amount > 0 && amount < a.getBalance()) {
	accountDao.updateAccountWithdraw(a, amount);
	System.out.println(amount + " has been withdrawn from Account "+a.getAccountNumber());
	}else {
		System.out.println("Invalid amount");
	}
	}else {
		System.out.println("That account number is not in our database");
	}
}else if(option == 3) {
	System.out.println("Enter the account number of the account you'd like to transfer from");
	String id = br.readLine();
	System.out.println("Enter the account number of the account you'd like to transfer to");
	String id2 = br.readLine();
	Account a = new Account();
	Account a2 = new Account();
	if(!id.equals(id2)) {
	 a = accountDao.getAccountByAccountNumber(id);
	 a2 = accountDao.getAccountByAccountNumber(id2);
	}else {
		System.out.println("You cannot transfer to the same account");
		break;
	}
	if(a != null && a2 != null) {
	System.out.println("How much would you like to transfer?");
	double amount = Double.parseDouble(br.readLine());
	if(amount > 0 && amount < a.getBalance()) {
	accountDao.updateTransfer(a, a2,amount);
	System.out.println(amount + " has been transfered from Account "+a.getAccountNumber() + " and into Account "+a2.getAccountNumber());
	}else {
		System.out.println("Invalid amount");
	}
	}else {
		System.out.println("Invalid account numbers entered");
	}
}else if(option==4) {
	System.out.println("Enter the account number you'd like to close");
	String id = br.readLine();
	Account a = accountDao.getAccountByAccountNumber(id);
	if(a != null) {
		accountDao.updateCloseAccount(a);
	}else {
		System.out.println("That account doesn't exist");
	}
}else if(option == 5) {
	System.out.println("Enter the account number you'd like to open");
	String id = br.readLine();
	Account a = accountDao.getAccountByAccountNumber(id);
	if(a != null) {
		accountDao.updateOpenAccount(a);
	}else {
		System.out.println("That account doesn't exist in our database");
	}
}else if(option == 6) {
	logOutLoop = false;
	userLoop = false;
}

}*/

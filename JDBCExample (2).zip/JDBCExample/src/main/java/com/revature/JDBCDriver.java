package com.revature;

import java.util.Scanner;

import com.revature.bean.Account;
import com.revature.bean.User;
import com.revature.dao.AccountDao;
import com.revature.dao.AccountDaoImpl;
import com.revature.dao.UserDao;
import com.revature.dao.UserDaoImpl;
import com.revature.util.ConnectionFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCDriver {
	

/*private static String username = "";
private static String password = "";
private static String url = "";*/
private static UserDao userDao = new UserDaoImpl(ConnectionFactory.getConnection());
private static AccountDao accountDao = new AccountDaoImpl(ConnectionFactory.getConnection());

public static void main(String[] args) throws NumberFormatException, IOException {
	
	InputStreamReader r=new InputStreamReader(System.in);    
    BufferedReader br=new BufferedReader(r); 
        boolean mainLoop = true;
          
        while(mainLoop){
        	boolean logOutLoop = true;
            boolean userLoop = true;
            System.out.println("Enter a username");
        	String uname = br.readLine();
        	System.out.println("Enter a password");
        	String password = br.readLine();
        System.out.println("Are you a \n1. customer\n2. employee\n3. admin");
       
        int x = Integer.parseInt(br.readLine());

        switch(x) {
        case 1:
        	CustomerView cv = new CustomerView(uname,password);
        break;
        
        case 2:
        	EmployeeView ev = new EmployeeView(uname,password);
        break;
        
        case 3:
        	AdminView av =new AdminView(uname,password);
        	break;
        }
        }
	}



}

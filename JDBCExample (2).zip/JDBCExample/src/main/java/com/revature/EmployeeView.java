package com.revature;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.revature.bean.Account;
import com.revature.bean.User;
import com.revature.dao.AccountDao;
import com.revature.dao.AccountDaoImpl;
import com.revature.dao.UserDao;
import com.revature.dao.UserDaoImpl;
import com.revature.util.ConnectionFactory;

public class EmployeeView {


private static UserDao userDao = new UserDaoImpl(ConnectionFactory.getConnection());
private static AccountDao accountDao = new AccountDaoImpl(ConnectionFactory.getConnection());

public EmployeeView(String uname,String password) throws NumberFormatException, IOException {
	boolean userLoop = true;
	boolean logOutLoop = true;
InputStreamReader r=new InputStreamReader(System.in);    
BufferedReader br=new BufferedReader(r); 
int l_r;
	System.out.println("1. register\n2. login\n3. Edit info ");
	l_r = Integer.parseInt(br.readLine());
	if(l_r == 1) {
		 int rand = (int) (Math.random()*100000+1);
		System.out.println("Enter a ssn");
		String ssn = br.readLine();
		System.out.println("Enter a phone number");
		String phone = br.readLine();
		userDao.createUser(new User(rand,uname,password,ssn,phone,2));
	}else if(l_r == 2) {
		User u = userDao.getUserByUsername(uname);
		if(u != null) {
			if(u.getUsername().equals(uname) && u.getPassword().equals(password) && u.getType() == 2) {
			System.out.println("\nLog in successful\n");
		}else {
			System.out.println("\nLog in failed\n");
			logOutLoop = false;
			userLoop = false;
		}
		}else {
			System.out.println("That username is not in our database");
			logOutLoop = false;
			userLoop = false;
		}
	}else if(l_r == 3) {
		System.out.println("Select your new password");
		String newPassword = br.readLine();
		User u = userDao.getUserByUsername(uname);
		u.setPassword(newPassword);
		userDao.updateUser(u);
	}
	while(userLoop) {
employeeMenu();
int option = Integer.parseInt(br.readLine());

if(option == 1) {
	System.out.println("\nNow going through list of customers. Press 'a' to approve a customer and press 'd' to deny a customer\n");
	for(User u : userDao.getAllUsers()) {
		if(userDao.getAllUsers().size() > 0) {
		if(!u.getApprovedStatus() && u.getType() == 1) {
			System.out.println("Username: "+u.getUsername()+"\nPhone number: "+u.getPhone()+"\n");
			System.out.println("\nPress a to approve, press d to deny.");
			char s = br.readLine().charAt(0);
			if(s == 'a' || s =='A') {
				u.setStatus(true);
				System.out.println("User "+u.getUsername()+" has been approved\n");
				userDao.updateUser(u);
			}else if(s=='d' || s == 'D') {
				u.setStatus(false);
				System.out.println("User "+u.getUsername()+" has been denied\n");
				userDao.updateUser(u);
			}
		}
	}else {
		System.out.println("\nAll the customers have been approved!\n");
	}
}
	
}else if(option == 2) {
	System.out.println("Enter the username of the user you'd like to search");
	String username = br.readLine();
	User u = userDao.getUserByUsername(username);
	if(u != null) {
	System.out.println(u.toString());
	}else {
		System.out.println("That user name doesn't exist in our database");
	}
}else if(option == 3) {
	System.out.println("Enter the account number of the account you'd like to search");
	String acc_no = br.readLine();
	Account a = accountDao.getAccountByAccountNumber(acc_no);
	if(a != null) {
	System.out.println(a.toString());
	}else {
		System.out.println("That account doesn't exist in our database");
	}
}else if(option == 4) {
	logOutLoop = false;
	userLoop = false;
}

	}
}

static void employeeMenu(){
    System.out.println("What would you like to do?" + 
    		"\n1. Approve or Deny users\n2. View customer info \n3.  View Account info" + 
    		"\n4. Log out");
}
}

/*
System.out.println("1. register\n2. login\n3. Edit info ");
l_r = Integer.parseInt(br.readLine());
if(l_r == 1) {
	 int rand = (int) (Math.random()*100000+1);
	System.out.println("Enter a ssn");
	String ssn = br.readLine();
	System.out.println("Enter a phone number");
	String phone = br.readLine();
	userDao.createUser(new User(rand,uname,password,ssn,phone,2));
}else if(l_r == 2) {
	User u = userDao.getUserByUsername(uname);
	if(u != null) {
		if(u.getUsername().equals(uname) && u.getPassword().equals(password) && u.getType() == 2) {
		System.out.println("\nLog in successful\n");
	}else {
		System.out.println("\nLog in failed\n");
		logOutLoop = false;
	}
	}else {
		System.out.println("That username is not in our database");
		logOutLoop = false;
	}
}else if(l_r == 3) {
	System.out.println("Select your new password");
	String newPassword = br.readLine();
	User u = userDao.getUserByUsername(uname);
	u.setPassword(newPassword);
	userDao.updateUser(u);
}
while(userLoop) {
employeeMenu();
int option = Integer.parseInt(br.readLine());

if(option == 1) {
System.out.println("\nNow going through list of customers. Press 'a' to approve a customer and press 'd' to deny a customer\n");
for(User u : userDao.getAllUsers()) {
	if(userDao.getAllUsers().size() > 0) {
	if(!u.getApprovedStatus() && u.getType() == 1) {
		System.out.println("Username: "+u.getUsername()+"\nPhone number: "+u.getPhone()+"\n");
		System.out.println("\nPress a to approve, press d to deny.");
		char s = br.readLine().charAt(0);
		if(s == 'a' || s =='A') {
			u.setStatus(true);
			System.out.println("User "+u.getUsername()+" has been approved\n");
			userDao.updateUser(u);
		}else if(s=='d' || s == 'D') {
			u.setStatus(false);
			System.out.println("User "+u.getUsername()+" has been denied\n");
			userDao.updateUser(u);
		}
	}
}else {
	System.out.println("\nAll the customers have been approved!\n");
}
}

}else if(option == 2) {
System.out.println("Enter the username of the user you'd like to search");
String username = br.readLine();
User u = userDao.getUserByUsername(username);
if(u != null) {
System.out.println(u.toString());
}else {
	System.out.println("That user name doesn't exist in our database");
}
}else if(option == 3) {
System.out.println("Enter the account number of the account you'd like to search");
String acc_no = br.readLine();
Account a = accountDao.getAccountByAccountNumber(acc_no);
if(a != null) {
System.out.println(a.toString());
}else {
	System.out.println("That account doesn't exist in our database");
}
}else if(option == 4) {
logOutLoop = false;
userLoop = false;
}

}*/

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.revature.bean;

import java.util.Date;

/**
 *
 * @author damaniobie
 */
public class LoggingTransactions {
    
    private int id;
    private Date timestamp;
    private String description;
    private int amount;
    
    public LoggingTransactions(){
        super();
    }
    
    public LoggingTransactions(int id, Date timestamp,String description,int amount){
        this.id = id;
        this.timestamp = timestamp;
        this.description = description;
        this.amount = amount;
    }
    
    public int getId(){
        return this.id;
    }
    
    public void setId(int id){
        this.id = id;
    }
    
    public Date getTimeStamp(){
        return this.timestamp;
    }
    
    public void setTimeStamp(Date d){
        this.timestamp = d;
    }
    
    public String getDesc(){
        return this.description;
    }
    
    public void setDesc(String desc){
        this.description = desc;
    }
    
    public int getAmount(){
        return this.amount;
    }
    
    public void setAmount(int amount){
        this.amount = amount;
    }
    
    public String toString(){
        return "Logging ID: "+this.getId()+"\nDate: "+this.getTimeStamp()+"\nAmount: " +this.getAmount()+ "\nDetails: "+this.getDesc();
    }
    
}

package com.revature.bean;

import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

public class User {
	
	public static int numUsers = 0;
	private int id;
	private int[] accountlist;
	private String username;
	private String password;
        private String ssn;
        private String phone;
        private int type;
        private boolean approved = false; //is approved or not
		private String accountNumber;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
        public String getssn() {
		return ssn;
	}
	public void setssn(String ssn) {
		this.ssn = ssn;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
        public boolean getApprovedStatus() {
        	return this.approved;
       }
        
        public void setStatus(boolean approved){
            this.approved = approved;
        }
        
        public int [] getAccountList() {
        	return this.accountlist;
        }
        
        public void setAccountList(int [] l) {
        	this.accountlist = l;
        }
        
        public void setAccountNumber(String acc) {
        	this.accountNumber = acc;
        }
        
        public String getAccountNumber() {
        	return this.accountNumber;
        }
      
        
	@Override
	public String toString() {
		return "id=" + id + "\nUsername: " + username + "\nPassword: " + password + "\nSocial Security: "+ssn+""
				+ "\nPhone: "+phone+"\nType: "+type;
	}
	
	public User(int id, String username, String password) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.accountlist = new int[3];
	}
        
        public User(int id, String username, String password, String ssn,String phone,int type) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
        this.type = type;
        this.phone = phone;
        this.ssn = ssn;
        this.accountlist = new int[3];
        numUsers++;
	}
        
	public User() {
		super();
	}
}

package com.revature;

import java.util.Scanner;

import com.revature.bean.Account;
import com.revature.bean.User;
import com.revature.dao.AccountDao;
import com.revature.dao.AccountDaoImpl;
import com.revature.dao.UserDao;
import com.revature.dao.UserDaoImpl;
import com.revature.util.ConnectionFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCDriver {
	

/*private static String username = "";
private static String password = "";
private static String url = "";*/
private static UserDao userDao = new UserDaoImpl(ConnectionFactory.getConnection());
private static AccountDao accountDao = new AccountDaoImpl(ConnectionFactory.getConnection());

public static void main(String[] args) throws NumberFormatException, IOException {
	
	InputStreamReader r=new InputStreamReader(System.in);    
    BufferedReader br=new BufferedReader(r); 
        boolean mainLoop = true;
        
        int l_r;
        
        while(mainLoop){
        	boolean logOutLoop = true;
            boolean userLoop = true;
            System.out.println("Enter a username");
        	String uname = br.readLine();
        	System.out.println("Enter a password");
        	String password = br.readLine();
        System.out.println("Are you a \n1. customer\n2. employee\n3. admin");
       
        int x = Integer.parseInt(br.readLine());

        
        while(logOutLoop) {
        switch(x) {
        case 1:
        	System.out.println("1. register\n2. login\n3. Change password ");
        	l_r = Integer.parseInt(br.readLine());
        	if(l_r == 1) {
        		 int rand = (int) (Math.random()*1000+1);
        		System.out.println("Enter a ssn");
        		String ssn = br.readLine();
        		System.out.println("Enter a phone number");
        		String phone = br.readLine();
        		userDao.createUser(new User(rand,uname,password,ssn,phone,1));
        	}else if(l_r == 2) {
        		User u = userDao.getUserByUsername(uname);
        		if(u != null) {
        			if(u.getUsername().equals(uname) && u.getPassword().equals(password) && u.getType() == 1) {
        			System.out.println("\nLog in successful\n");
        		}else {
        			System.out.println("\nLog in failed\n");
        			logOutLoop = false;
        		}
        		}else {
        			System.out.println("That username is not in our database");
        			logOutLoop = false;
        		}
        	}else if(l_r == 3) {
        		System.out.println("Select your new password");
        		String newPassword = br.readLine();
        		User u = userDao.getUserByUsername(uname);
        		u.setPassword(newPassword);
        		userDao.updateUser(u);
        	}
        	while(userLoop) {
        customerMenu();
        int option = Integer.parseInt(br.readLine());
        if(option == 1) {
        	 int rand = (int) (Math.random()*100000+1);
        	if(userDao.getUserByUsername(uname).getApprovedStatus()) {
        		User u = userDao.getUserByUsername(uname);
        		accountDao.createAccount(new Account(rand,false,0.0,u));
        		Account a = accountDao.getAccountById(rand);
        		System.out.println("Account Successfully added. Account number is: "+a.getAccountNumber());
        		userDao.getUserByUsername(uname).setAccountNumber(a.getAccountNumber());
        		userDao.updateUser(u);
        	}else {
        		System.out.println("You must first be approved by an employee");
        	}
        }else if(option == 2) {
        	 int rand = (int) (Math.random()*100000+1);
        	if(userDao.getUserByUsername(uname).getApprovedStatus()) {
        		User u = userDao.getUserByUsername(uname);
        		accountDao.createAccount(new Account(rand,true,0.0,userDao.getUserByUsername(uname)));
        		Account a = accountDao.getAccountById(rand);
        		System.out.println("Account Successfully added. Account number is: "+a.getAccountNumber());
        		userDao.getUserByUsername(uname).setAccountNumber(a.getAccountNumber());
        		userDao.updateUser(u);
        	}else {
        		System.out.println("You must first be approved by an employee");
        	}
        }else if(option == 3) {
        	if(userDao.getUserByUsername(uname).getAccountNumber() != null) {
        		System.out.println("Enter the account number of the account you'd like to deposit");
        		String id = br.readLine();
        		Account a = accountDao.getAccountByAccountNumber(id);
        		System.out.println("How much would you like to deposit?");
        		double amount = Double.parseDouble(br.readLine());
        		if(amount > 0) {
        		accountDao.updateAccountDeposit(a, amount);
        		System.out.println(amount + " has been deposited into Account "+a.getAccountNumber());
        		}else {
        			System.out.println("Invalid amount");
        		}
        	}else {
        		System.out.println("You must first apply for an account");
        	}
        }else if(option == 4) {
        	if(userDao.getUserByUsername(uname).getAccountNumber() != null) {
        		System.out.println("Enter the account number of the account you'd like to withdraw");
        		String id = br.readLine();
        		Account a = accountDao.getAccountByAccountNumber(id);
        		System.out.println("How much would you like to withdraw?");
        		double amount = Double.parseDouble(br.readLine());
        		if(amount > 0 && amount < a.getBalance()) {
        		accountDao.updateAccountWithdraw(a, amount);
        		System.out.println(amount + " has been withdrawn from Account "+a.getAccountNumber());
        		}else {
        			System.out.println("Invalid amount");
        		}
        	}else {
        		System.out.println("You must first apply for an account");
        	}
        }else if(option == 5) {
        	if(userDao.getUserByUsername(uname).getAccountNumber() != null) {
        		System.out.println("Enter the account number of the account you'd like to transfer from");
        		String id = br.readLine();
        		System.out.println("Enter the account number of the account you'd like to transfer to");
        		String id2 = br.readLine();
        		Account a = accountDao.getAccountByAccountNumber(id);
        		Account a2 = accountDao.getAccountByAccountNumber(id2);
        		System.out.println("How much would you like to transfer?");
        		double amount = Double.parseDouble(br.readLine());
        		if(amount > 0 && amount < a.getBalance()) {
        		accountDao.updateTransfer(a, a2,amount);
        		System.out.println(amount + " has been transfered from Account "+a.getAccountNumber() + " and into Account "+a2.getAccountNumber());
        		}else {
        			System.out.println("Invalid amount");
        		}
        	}else {
        		System.out.println("You must first apply for an account");
        	}
        }else if(option == 6) {
        	if(userDao.getUserByUsername(uname).getAccountNumber() != null) {
        		System.out.println("Enter the account number of the account you'd like to check");
        		String id = br.readLine();
        		Account a = accountDao.getAccountByAccountNumber(id);
        		accountDao.seeAccountInfo(a);
        	}
        }else if(option == 7) {
        	userLoop = false;
        	logOutLoop = false;
        }
        	}
        break;
        
        case 2:
        	System.out.println("1. register\n2. login\n3. Edit info ");
        	l_r = Integer.parseInt(br.readLine());
        	if(l_r == 1) {
        		 int rand = (int) (Math.random()*100000+1);
        		System.out.println("Enter a ssn");
        		String ssn = br.readLine();
        		System.out.println("Enter a phone number");
        		String phone = br.readLine();
        		userDao.createUser(new User(rand,uname,password,ssn,phone,2));
        	}else if(l_r == 2) {
        		User u = userDao.getUserByUsername(uname);
        		if(u != null) {
        			if(u.getUsername().equals(uname) && u.getPassword().equals(password) && u.getType() == 2) {
        			System.out.println("\nLog in successful\n");
        		}else {
        			System.out.println("\nLog in failed\n");
        			logOutLoop = false;
        		}
        		}else {
        			System.out.println("That username is not in our database");
        			logOutLoop = false;
        		}
        	}else if(l_r == 3) {
        		System.out.println("Select your new password");
        		String newPassword = br.readLine();
        		User u = userDao.getUserByUsername(uname);
        		u.setPassword(newPassword);
        		userDao.updateUser(u);
        	}
        	while(userLoop) {
        employeeMenu();
        int option = Integer.parseInt(br.readLine());
        
        if(option == 1) {
        	System.out.println("\nNow going through list of customers. Press 'a' to approve a customer and press 'd' to deny a customer\n");
        	for(User u : userDao.getAllUsers()) {
        		if(!u.getApprovedStatus() && u.getType() == 1) {
        			System.out.println("Username: "+u.getUsername()+"\nPhone number: "+u.getPhone()+"\n");
        			System.out.println("\nPress a to approve, press d to deny.");
        			char s = br.readLine().charAt(0);
        			if(s == 'a' || s =='A') {
        				u.setStatus(true);
        				System.out.println("User "+u.getUsername()+" has been approved\n");
        				userDao.updateUser(u);
        			}else if(s=='d' || s == 'D') {
        				u.setStatus(false);
        				System.out.println("User "+u.getUsername()+" has been denied\n");
        				userDao.updateUser(u);
        			}
        		}
        	}
        	
        }else if(option == 2) {
        	System.out.println("Enter the username of the user you'd like to search");
        	String username = br.readLine();
        	User u = userDao.getUserByUsername(username);
        	if(u != null) {
        	u.toString();
        	}else {
        		System.out.println("That user name doesn't exist in our database");
        	}
        }else if(option == 3) {
        	System.out.println("Enter the account number of the account you'd like to search");
        	String acc_no = br.readLine();
        	Account a = accountDao.getAccountByAccountNumber(acc_no);
        	if(a != null) {
        	a.toString();
        	}else {
        		System.out.println("That account doesn't exist in our database");
        	}
        }else if(option == 4) {
        	logOutLoop = false;
        	userLoop = false;
        }
        
        	}
        break;
        
        case 3:
        	System.out.println("1. register\n2. login\n3. Edit info");
        	l_r = Integer.parseInt(br.readLine());
        	if(l_r == 1) {
        		 int rand = (int) (Math.random()*100000+1);
        		System.out.println("Enter a ssn");
        		String ssn = br.readLine();
        		System.out.println("Enter a phone number");
        		String phone = br.readLine();
        		userDao.createUser(new User(rand,uname,password,ssn,phone,3));
        	}else if(l_r == 2) {
        		User u = userDao.getUserByUsername(uname);
        		if(u != null) {
        			if(u.getUsername().equals(uname) && u.getPassword().equals(password) && u.getType() == 1) {
        			System.out.println("\nLog in successful\n");
        		}else {
        			System.out.println("\nLog in failed\n");
        			logOutLoop = false;
        			userLoop = false;
        		}
        		}else {
        			System.out.println("That username is not in our database");
        			logOutLoop = false;
        			userLoop = false;
        		}
        	}else if(l_r == 3) {
        		System.out.println("Select your new password");
        		String newPassword = br.readLine();
        		User u = userDao.getUserByUsername(uname);
        		u.setPassword(newPassword);
        		userDao.updateUser(u);
        	}
        	while(userLoop) {
        	adminMenu();
        	int option = Integer.parseInt(br.readLine());
        	
        	if(option == 1) {
        		System.out.println("Enter the account number of the account you'd like to deposit");
        		String id = br.readLine();
        		Account a = accountDao.getAccountByAccountNumber(id);
        		if(a != null) {
        		System.out.println("How much would you like to deposit?");
        		double amount = Double.parseDouble(br.readLine());
        		if(amount > 0) {
        		accountDao.updateAccountDeposit(a, amount);
        		System.out.println(amount + " has been deposited into Account "+a.getAccountNumber());
        		}else {
        			System.out.println("Invalid amount");
        		}
        		}else {
        			System.out.println("That account number is not in our database");
        		}
        	}else if(option == 2) {
        		System.out.println("Enter the account number of the account you'd like to withdraw");
        		String id = br.readLine();
        		Account a = accountDao.getAccountByAccountNumber(id);
        		if(a != null) {
        		System.out.println("How much would you like to withdraw?");
        		double amount = Double.parseDouble(br.readLine());
        		if(amount > 0 && amount < a.getBalance()) {
        		accountDao.updateAccountWithdraw(a, amount);
        		System.out.println(amount + " has been withdrawn from Account "+a.getAccountNumber());
        		}else {
        			System.out.println("Invalid amount");
        		}
        		}else {
        			System.out.println("That account number is not in our database");
        		}
        	}else if(option == 3) {
        		System.out.println("Enter the account number of the account you'd like to transfer from");
        		String id = br.readLine();
        		System.out.println("Enter the account number of the account you'd like to transfer to");
        		String id2 = br.readLine();
        		Account a = accountDao.getAccountByAccountNumber(id);
        		Account a2 = accountDao.getAccountByAccountNumber(id2);
        		if(a != null && a2 != null) {
        		System.out.println("How much would you like to transfer?");
        		double amount = Double.parseDouble(br.readLine());
        		if(amount > 0 && amount < a.getBalance()) {
        		accountDao.updateTransfer(a, a2,amount);
        		System.out.println(amount + " has been transfered from Account "+a.getAccountNumber() + " and into Account "+a2.getAccountNumber());
        		}else {
        			System.out.println("Invalid amount");
        		}
        		}else {
        			System.out.println("Invalid account numbers entered");
        		}
        	}else if(option==4) {
        		System.out.println("Enter the account number you'd like to cancel");
        		String id = br.readLine();
        		Account a = accountDao.getAccountByAccountNumber(id);
        		if(a != null) {
        			accountDao.deleteAccount(a);
        		}else {
        			System.out.println("That account doesn't exist");
        		}
        	}else if(option == 5) {
        		logOutLoop = false;
        		userLoop = false;
        	}
        	
        	}
        	break;
        }
        }
        
/*	System.out.println("Do you wish to change your password?");
	Scanner sc = new Scanner(System.in);
	if ("yes".equals(sc.nextLine().toLowerCase())){
		/*System.out.println("Please enter your id");
		Integer id = sc.nextInt();
		sc.nextLine();
		System.out.println("Please enter new username");
		String username = sc.nextLine();
		System.out.println("Please enter new password");
		String password2 = sc.nextLine();
		//userDao.updateUser(new User(-1, username, password));
                */
                
       // }
	}

}

static void customerMenu(){
    System.out.println("What would you like to do?"
            + "\n1. Apply for an account\n2. Apply for a joint account"
            + "\n3. Deposit funds\n4. Withdraw\n5. Transfer funds\n6. Check account info \n7. Logout");
}

static void employeeMenu(){
    System.out.println("What would you like to do?" + 
    		"\n1. Approve or Deny users\n2. View customer info \n3.  View Account info" + 
    		"\n4. Log out");
}

static void adminMenu(){
	System.out.println("What would you like to do?" + 
    		"\n1. Deposit\n2. Withdraw \n3. Transfer" + 
    		"\n4. Cancel Account\n5. Log out\n");
}
	


}

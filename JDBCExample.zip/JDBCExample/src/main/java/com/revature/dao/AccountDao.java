/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.revature.dao;

import java.io.IOException;
import java.util.List;

import com.revature.bean.Account;

/**
 *
 * @author damaniobie
 */
public interface AccountDao {
    
    public void createAccount(Account a);
	
	public void updateAccount(Account a) throws NumberFormatException, IOException;
	
	public void deleteAccount(Account a);
	
	public Account getAccountById(Integer id);
	
	public Account getAccountByAccountNumber(String accountNumber);
	
	public List<Account> getAllAccounts();
	
	public void updateAccountDeposit(Account a, double amount);
	
	public void updateAccountWithdraw(Account a, double amount);
	
	public void updateTransfer(Account a, Account b, double amount);
	
	public void updateOpenAccount(Account a);
	
	public void updateSetJoint(Account a);
	
	public void seeAccountInfo(Account acc);

	//void preparedUpdateAccount(Account a);
    
}

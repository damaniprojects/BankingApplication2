package com.revature.dao;

import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.revature.bean.User;
import java.util.ArrayList;

public class UserDaoImpl implements UserDao {

	private Connection conn;

	public void createUser(User u) {
        try {
            PreparedStatement pstmt = conn.prepareStatement("Insert into user_table (user_id,username,password,ssn,phone,type,approved,account_list) values (?,?,?,?,?,?,?,?)");
            pstmt.setInt(1, User.numUsers);
            pstmt.setString(2,u.getUsername());
            pstmt.setString(3,u.getPassword());
            pstmt.setString(4,u.getssn());
            pstmt.setString(5,u.getPhone());
            pstmt.setInt(6,u.getType());
            pstmt.setBoolean(7, u.getApprovedStatus());
            pstmt.setString(8,u.getAccountNumber());
            pstmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}

       /*	@Override
	public void updateUser(User u) {
		try {
			Statement stmt = conn.createStatement();
			String query = "update user_table set password = '" + u.getPassword() + "' where username = '" + u.getUsername() + "'";
			stmt.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
        */

	
	public void updateUser(User u){
		try {
			PreparedStatement pstmt = conn.prepareStatement("update user_table set password = ?,approved = ?,account_list = ? where username = ?");
			pstmt.setString(1, u.getPassword());
			pstmt.setBoolean(2, u.getApprovedStatus());
			pstmt.setString(3, u.getAccountNumber());
			pstmt.setString(4, u.getUsername());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void deleteUser(User u) {
		try{
                    PreparedStatement pstmt = conn.prepareStatement("delete from user_table where user_id = ?");
                    pstmt.setInt(1, u.getId());
                    pstmt.executeUpdate();
                }catch(SQLException e){
                    e.printStackTrace();
                }

	}

	
	public User getUserById(Integer id) {
		User ret = null;
		try {
                    PreparedStatement pstmt = conn.prepareStatement("select * from user_table where user_id = ?");
                        pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				ret = new User();
				ret.setId(rs.getInt(1));
				ret.setUsername(rs.getString("username"));
				ret.setPassword(rs.getString("password"));
                ret.setssn(rs.getString("ssn"));
                ret.setPhone(rs.getString("phone"));
                ret.setType(rs.getInt("type"));
                ret.setStatus(rs.getBoolean("approved"));
                ret.setAccountNumber( rs.getString("account_list"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ret;
	}

	
	public User getUserByUsername(String username) {
		User ret = null;
		try {
                    PreparedStatement pstmt = conn.prepareStatement("select * from user_table where username = ?");
                        pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				ret = new User();
				ret.setId(rs.getInt(1));
				ret.setUsername(rs.getString("username"));
				ret.setPassword(rs.getString("password"));
                                ret.setssn(rs.getString("ssn"));
                                ret.setPhone(rs.getString("phone"));
                                ret.setType(rs.getInt("type"));
                                ret.setStatus(rs.getBoolean("approved"));
                                ret.setAccountNumber(rs.getString("account_list"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ret;
	}

	
	public List <User> getAllUsers() {
			User u = null;
            List <User> userList = new ArrayList<User>();
		try{
                    PreparedStatement pstmt = conn.prepareStatement("select * from user_table");
                    ResultSet rs = pstmt.executeQuery();
                    while(rs.next()){
                    	u = new User();
        				u.setId(rs.getInt(1));
        				u.setUsername(rs.getString("username"));
        				u.setPassword(rs.getString("password"));
                        u.setssn(rs.getString("ssn"));
                        u.setPhone(rs.getString("phone"));
                        u.setType(rs.getInt("type"));
                        u.setStatus(rs.getBoolean("approved"));
                        u.setAccountNumber(rs.getString("account_list"));
                        userList.add(u);
                    }
                }catch(SQLException e){
                    e.printStackTrace();
                }
		return userList;
	}

	public UserDaoImpl() {
		super();
	}

	public UserDaoImpl(Connection conn) {
		super();
		this.conn = conn;
	}

}
